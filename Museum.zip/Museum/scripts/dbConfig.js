let config = {
    host: 'sql7.freemysqlhosting.net',
    user: 'sql7271639',
    password: 'Lyv6NhQri7',
    database: 'sql7271639'
}

/*let config = {
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'mkm'
}*/

module.exports = config;